import 'package:flutter_riverpod/flutter_riverpod.dart';

class Todo {
  String title;
  bool completed;

  Todo({required this.title, this.completed = false});

  void toggleCompleted() {
    completed = !completed;
  }
}


class TodosNotifier extends Notifier<List<Todo>> {
  

  void toggleTodo(Todo todo) {
    state = [
      for (final t in state)
        if (t == todo)
          Todo(title: t.title, completed: !t.completed)
        else
          t,
    ];
  }

  void deleteTodo(Todo todo) {
    state = state.where((t) => t != todo).toList();
  }
}


